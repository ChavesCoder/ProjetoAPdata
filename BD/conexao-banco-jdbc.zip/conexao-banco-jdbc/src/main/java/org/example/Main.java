package org.example;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

//import java.sql.Connection;
//try (Connection conn = conexao.getConexao().getConnection()) {
//        if (conn != null && !conn.isClosed()) {
//        System.out.println("Conexão bem-sucedida!");
//            }
//                    } catch (Exception e) {
//        e.printStackTrace();
//        }
//CODIGO PARA TESTAR CONEXÃO COM O BANCO

public class Main {
    public static void main(String[] args) {
    Conexao conexao = new Conexao();
    JdbcTemplate template =new JdbcTemplate(conexao.getConexao());

    // template.execute(""); // /utiliza mais para criação de tabela

//        template.update("INSERT INTO empresa (nome_empresa, nome_ficticio, cnpj, endereco, email, senha, telefone)\n" +
//                "VALUES \n" +
//                "  ('Construtora Alpha Ltda', 'Alpha Imóveis', '12345678000199', 'Rua das Palmeiras, 123 - SP', 'contato@alphaimoveis.com', 'senha123', '(11) 99999-1111'),\n" +
//                "  ('Imobiliária Beta S/A', 'Beta Real State', '98765432000155', 'Av. Central, 456 - RJ', 'beta@imoveis.com', 'beta456', '(21) 98888-2222');\n");

        List<Empresa> empresas = template.query("SELECT * FROM empresa;", new BeanPropertyRowMapper<>(Empresa.class));

        System.out.println(empresas);

        System.out.println("UPDATE");
//        template.update("UPDATE empresa SET nome_empresa=? where id_empresa=?", "EmpresaTeste", 1);
        empresas = template.query("SELECT * FROM empresa;", new BeanPropertyRowMapper<>(Empresa.class));
        System.out.println(empresas);
        template.update("UPDATE empresa SET email = ? where id_empresa = ?", "pedrorogerio@acordo.com", 2);

        System.out.println("DELETE");
        template.update("DELETE FROM empresa where id_empresa=?", 2);
        empresas = template.query("SELECT * FROM empresa;", new BeanPropertyRowMapper<>(Empresa.class));
        System.out.println(empresas);

        // queryForObject
        Empresa empresa = template.queryForObject("SELECT * FROM empresa where id_empresa =?", new BeanPropertyRowMapper<>(Empresa.class),1);
        System.out.println(empresa);


    }
}