package org.example;

import java.time.LocalDate;

public class Regiao {
    private Integer idRegiao;
    private String estado;
    private String municipio;
    private String zona;
    private String condicaoDomicilio;
    private LocalDate data;
    private Integer qtdRegistros;


    public Integer getIdRegiao() {
        return idRegiao;
    }

    public void setIdRegiao(Integer idRegiao) {
        this.idRegiao = idRegiao;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }

    public String getCondicaoDomicilio() {
        return condicaoDomicilio;
    }

    public void setCondicaoDomicilio(String condicaoDomicilio) {
        this.condicaoDomicilio = condicaoDomicilio;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public Integer getQtdRegistros() {
        return qtdRegistros;
    }

    public void setQtdRegistros(Integer qtdRegistros) {
        this.qtdRegistros = qtdRegistros;
    }

    @Override
    public String toString() {
        return "Regiao{" +
                "idRegiao=" + idRegiao +
                ", estado='" + estado + '\'' +
                ", municipio='" + municipio + '\'' +
                ", zona='" + zona + '\'' +
                ", condicaoDomicilio='" + condicaoDomicilio + '\'' +
                ", data=" + data +
                ", qtdRegistros=" + qtdRegistros +
                '}';
    }
}
