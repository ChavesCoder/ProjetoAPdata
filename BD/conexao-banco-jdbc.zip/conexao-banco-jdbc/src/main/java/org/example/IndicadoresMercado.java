package org.example;

public class IndicadoresMercado {
    private Integer idIndicador;
    private Integer numIndice;
    private Double variacaoMensal;
    private Double variacaoAnual;
    private Double rentabilidadeMensal;
    private Integer qtdMoradores;
    private Integer fkRegiao;

    public Integer getIdIndicador() {
        return idIndicador;
    }

    public void setIdIndicador(Integer idIndicador) {
        this.idIndicador = idIndicador;
    }

    public Integer getNumIndice() {
        return numIndice;
    }

    public void setNumIndice(Integer numIndice) {
        this.numIndice = numIndice;
    }

    public Double getVariacaoMensal() {
        return variacaoMensal;
    }

    public void setVariacaoMensal(Double variacaoMensal) {
        this.variacaoMensal = variacaoMensal;
    }

    public Double getVariacaoAnual() {
        return variacaoAnual;
    }

    public void setVariacaoAnual(Double variacaoAnual) {
        this.variacaoAnual = variacaoAnual;
    }

    public Double getRentabilidadeMensal() {
        return rentabilidadeMensal;
    }

    public void setRentabilidadeMensal(Double rentabilidadeMensal) {
        this.rentabilidadeMensal = rentabilidadeMensal;
    }

    public Integer getQtdMoradores() {
        return qtdMoradores;
    }

    public void setQtdMoradores(Integer qtdMoradores) {
        this.qtdMoradores = qtdMoradores;
    }

    public Integer getFkRegiao() {
        return fkRegiao;
    }

    public void setFkRegiao(Integer fkRegiao) {
        this.fkRegiao = fkRegiao;
    }

    @Override
    public String toString() {
        return "IndicadoresMercado{" +
                "idIndicador=" + idIndicador +
                ", numIndice=" + numIndice +
                ", variacaoMensal=" + variacaoMensal +
                ", variacaoAnual=" + variacaoAnual +
                ", rentabilidadeMensal=" + rentabilidadeMensal +
                ", qtdMoradores=" + qtdMoradores +
                ", fkRegiao=" + fkRegiao +
                '}';
    }
}
