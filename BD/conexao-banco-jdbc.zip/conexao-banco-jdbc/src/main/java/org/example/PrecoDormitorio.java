package org.example;

public class PrecoDormitorio {
    private Integer idPreco;
    private Integer fkIndicador;
    private Byte dormitorios;
    private Double precoMedio;

    public Integer getIdPreco() {
        return idPreco;
    }

    public void setIdPreco(Integer idPreco) {
        this.idPreco = idPreco;
    }

    public Integer getFkIndicador() {
        return fkIndicador;
    }

    public void setFkIndicador(Integer fkIndicador) {
        this.fkIndicador = fkIndicador;
    }

    public Byte getDormitorios() {
        return dormitorios;
    }

    public void setDormitorios(Byte dormitorios) {
        this.dormitorios = dormitorios;
    }

    public Double getPrecoMedio() {
        return precoMedio;
    }

    public void setPrecoMedio(Double precoMedio) {
        this.precoMedio = precoMedio;
    }

    @Override
    public String toString() {
        return "PrecoDormitorio{" +
                "idPreco=" + idPreco +
                ", fkIndicador=" + fkIndicador +
                ", dormitorios=" + dormitorios +
                ", precoMedio=" + precoMedio +
                '}';
    }
}
