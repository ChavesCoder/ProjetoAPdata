package org.example;

import java.time.LocalDate;

public class Log {
    private Integer idLog;
    private LocalDate datetime;
    private String tipo;
    private String especificacao;
    private String descricao;
    private Integer fkUsuario;


    public Integer getIdLog() {
        return idLog;
    }

    public void setIdLog(Integer idLog) {
        this.idLog = idLog;
    }

    public LocalDate getDatetime() {
        return datetime;
    }

    public void setDatetime(LocalDate datetime) {
        this.datetime = datetime;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEspecificacao() {
        return especificacao;
    }

    public void setEspecificacao(String especificacao) {
        this.especificacao = especificacao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer getFkUsuario() {
        return fkUsuario;
    }

    public void setFkUsuario(Integer fkUsuario) {
        this.fkUsuario = fkUsuario;
    }

    @Override
    public String toString() {
        return "Log{" +
                "idLog=" + idLog +
                ", datetime=" + datetime +
                ", tipo='" + tipo + '\'' +
                ", especificacao='" + especificacao + '\'' +
                ", descricao='" + descricao + '\'' +
                ", fkUsuario=" + fkUsuario +
                '}';
    }
}
