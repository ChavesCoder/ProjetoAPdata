import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LogDashboardApData {

    private String usuario;
    private LocalDateTime entrada;
    private LocalDateTime saida;

    public LogDashboardApData(String usuario) {
        this.usuario = usuario;
        this.entrada = LocalDateTime.now();
        this.saida = null;
        registrarLog("INFO", "Login", "Usuário '" + usuario + "' acessou o dashboard.");
    }

    public void selecionarPeriodo(String periodo) {
        registrarLog("INFO", "Filtro", "Usuário selecionou período: " + periodo);
    }

    public void selecionarCidades(String... cidades) {
        registrarLog("INFO", "Filtro", "Usuário selecionou cidades: " + String.join(", ", cidades));
    }

    public void visualizarGrafico(String periodo) {
        registrarLog("INFO", "Gráfico", "Usuário visualizou gráfico de progressão para o período: " + periodo);
    }

    public void visualizarGraficoErro(String periodo) {
        registrarLog("ERRO", "Gráfico", "O gráfico de media de moradores por domicilio não apareceu: " + periodo);
    }

    public void verificarAlertas(String alerta) {
        registrarLog("ATENÇÃO", "Alerta", "Sistema gerou um alerta: " + alerta);
    }

    public void registrarSaida() {
        this.saida = LocalDateTime.now();
        registrarLog("INFO", "Logout", "Usuário '" + usuario + "' saiu do sistema.");
        System.out.println("Tempo total de sessão: " + calcularTempoSessao());
    }

    private String calcularTempoSessao() {
        if (saida == null) {
            return "Sessão ainda ativa";
        }
        Duration duracao = Duration.between(entrada, saida);
        long horas = duracao.toHours();
        long minutos = duracao.toMinutes() % 60;
        long segundos = duracao.toSeconds() % 60;
        return String.format("%02d:%02d:%02d", horas, minutos, segundos);
    }

    private void registrarLog(String tipo, String acao, String mensagem) {
        String dateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        System.out.println(dateTime + " | (" + tipo + ") | " + acao + " - " + mensagem);
    }

    public static void main(String[] args) {
        LogDashboardApData log = new LogDashboardApData("ADM APDATA");

        try {
            Thread.sleep(1000);
            log.selecionarPeriodo("Semestral");

            Thread.sleep(1500);
            log.selecionarCidades("Cidade 01", "Cidade 02", "Cidade 03", "Cidade 04");


            Thread.sleep(1200);
            log.visualizarGrafico("2024.1");


            Thread.sleep(1200);
            log.visualizarGraficoErro("Erro ao exibir a dashboard");


            Thread.sleep(1200);
            log.verificarAlertas("Variação de preços superior a 5% em Cidade 01.");

            Thread.sleep(1000);
            log.verificarAlertas("Número de registros insuficiente para análise detalhada.");

        } catch (InterruptedException e) {
            log.registrarLog("ERROR", "Sistema", "Thread interrompida: " + e.getMessage());
            Thread.currentThread().interrupt();
        }

        log.registrarSaida();
    }
}